package com.sun.mvpdemo.baselibrary.moudle

/**
 * @author sun
 * @data 2018-12-26
 * @Explain 退出
 */

class LogoutEvevt {}
