package com.sun.mvpdemo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.sun.mvpdemo.baselibrary.base.BaseActivity
import com.sun.mvpdemo.baselibrary.base.MvpActivity

class MainActivity : BaseActivity() {
    override fun initView(savedInstanceState: Bundle?) {
    }

    override fun layoutResID(): Int = R.layout.activity_main

}
