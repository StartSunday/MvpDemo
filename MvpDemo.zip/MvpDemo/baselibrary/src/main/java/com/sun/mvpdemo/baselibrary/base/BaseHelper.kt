package com.sun.mvpdemo.baselibrary.base

import android.support.v4.content.ContextCompat
import android.support.v4.widget.SwipeRefreshLayout
import android.view.View
import android.view.ViewGroup
import com.sun.mvpdemo.baselibrary.R

/**
* @author  sun
* @data 2019-01-03
* @Explain
*/
class BaseHelper {
    companion object {
        fun initSwipeRefreshLayoutColor(view: View) {
            val colorPrimary = ContextCompat.getColor(view.context, R.color.colorPrimary)
            if (view is SwipeRefreshLayout) {
                view.setColorSchemeColors(colorPrimary)
            } else if (view is ViewGroup) {
                for (i in 0 until view.childCount) {
                    initSwipeRefreshLayoutColor(view.getChildAt(i))
                }
            }
        }
    }
}