package com.sun.mvpdemo.baselibrary.base

/**
 * @author sun
 * @data 2018-12-25
 * @Explain baseview
 */
interface BaseView{

    fun showLoading()

    fun hideLoading()
}